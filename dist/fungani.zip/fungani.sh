#!/bin/sh

python -m fungani
